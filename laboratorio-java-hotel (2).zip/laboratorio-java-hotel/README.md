# Sistema de Gestión Hotelera - Java CLI

Sistema completo de gestión hotelera con interfaz de línea de comandos (CLI) desarrollado en Java con arquitectura por capas y persistencia en memoria.

## Características

- **Gestión de Clientes**: Registro, búsqueda y listado de clientes
- **Gestión de Habitaciones**: Visualización de habitaciones disponibles por tipo
- **Gestión de Reservas**: Creación, consulta, modificación y cancelación
- **Check-in/Check-out**: Proceso completo de entrada y salida
- **Validaciones**: Validación completa de datos de entrada
- **Estadísticas**: Panel de estadísticas del hotel

## Estructura del Proyecto

```
laboratorio-java-hotel/
├── src/
│   ├── model/
│   │   ├── Cliente.java        # Modelo de Cliente
│   │   ├── Habitacion.java     # Modelo de Habitación con enum TipoHabitacion
│   │   └── Reserva.java        # Modelo de Reserva con enum EstadoReserva
│   ├── data/
│   │   └── BaseDatosHotel.java # Simulación de base de datos en memoria
│   ├── service/
│   │   └── HotelService.java   # Lógica de negocio
│   └── SistemaHotel.java       # Clase principal con interfaz CLI
└── README.md
```

## Requisitos

- Java JDK 8 o superior

## Compilación

Desde el directorio raíz del proyecto:

```bash
javac -d bin src/model/*.java src/data/*.java src/service/*.java src/SistemaHotel.java
```

O compilar archivos individuales:

```bash
javac src/model/Cliente.java
javac src/model/Habitacion.java
javac src/model/Reserva.java
javac src/data/BaseDatosHotel.java
javac src/service/HotelService.java
javac src/SistemaHotel.java
```

## Ejecución

Después de compilar:

```bash
java -cp bin SistemaHotel
```

O si compiló sin el directorio bin:

```bash
java -cp src SistemaHotel
```

## Uso

El sistema presenta un menú interactivo con 14 opciones:

1. **Registrar Nuevo Cliente**: Alta de clientes con validación de datos
2. **Buscar Cliente**: Búsqueda por número de documento
3. **Listar Todos los Clientes**: Visualización de todos los clientes
4. **Ver Habitaciones Disponibles**: Lista completa de habitaciones libres
5. **Ver Habitaciones por Tipo**: Filtrado por tipo de habitación
6. **Crear Nueva Reserva**: Generación de reservas con validación
7. **Consultar Reserva**: Búsqueda por ID de reserva
8. **Ver Reservas de Cliente**: Historial de reservas por cliente
9. **Realizar Check-in**: Proceso de entrada al hotel
10. **Realizar Check-out**: Proceso de salida con cálculo de costos
11. **Cancelar Reserva**: Cancelación con liberación de habitación
12. **Ver Reservas Activas**: Lista de reservas confirmadas o en curso
13. **Calcular Costo de Estancia**: Estimación de costos por tipo y días
14. **Estadísticas del Hotel**: Panel de métricas del sistema

## Tipos de Habitación

- **Simple**: 1 persona - $50/noche
- **Doble**: 2 personas - $80-85/noche
- **Suite**: 4 personas - $150-160/noche
- **Presidencial**: 6 personas - $300/noche

## Arquitectura

### Capa de Modelo (model/)
- `Cliente`: Información personal y de contacto
- `Habitacion`: Datos de habitaciones con enum TipoHabitacion
- `Reserva`: Información de reservas con enum EstadoReserva

### Capa de Datos (data/)
- `BaseDatosHotel`: Gestión de datos en memoria con Listas estáticas

### Capa de Servicio (service/)
- `HotelService`: Lógica de negocio y validaciones

### Capa de Presentación
- `SistemaHotel`: Interfaz CLI interactiva

## Principios Aplicados

- **SOLID**: Separación de responsabilidades
- **Encapsulamiento**: Uso de getters/setters
- **Enumeraciones**: Para tipos y estados
- **Optional**: Manejo seguro de valores nulos
- **Streams**: Operaciones funcionales en colecciones
- **Exception Handling**: Try-catch en todas las operaciones

## Validaciones

- Campos obligatorios no vacíos
- Documentos únicos
- Fechas coherentes (check-in < check-out)
- Disponibilidad de habitaciones
- Estados de reserva válidos
- Fechas no pasadas

## Estados de Reserva

1. **PENDIENTE**: Reserva creada pero no confirmada
2. **CONFIRMADA**: Reserva confirmada, esperando check-in
3. **EN_CURSO**: Cliente ya hizo check-in
4. **FINALIZADA**: Check-out completado
5. **CANCELADA**: Reserva cancelada

## Formato de Fechas

Todas las fechas se ingresan en formato: `dd/MM/yyyy`

Ejemplo: `16/02/2026`

## Autor

Sistema desarrollado como proyecto educativo de gestión hotelera en Java.

## Licencia

Proyecto de código abierto para fines educativos.
