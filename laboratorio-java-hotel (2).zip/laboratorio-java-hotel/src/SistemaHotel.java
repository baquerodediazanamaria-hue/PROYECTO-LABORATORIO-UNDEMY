import model.Cliente;
import model.Habitacion;
import model.Habitacion.TipoHabitacion;
import model.Reserva;
import service.HotelService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

/**
 * Aplicación principal CLI para el Sistema de Gestión Hotelera.
 */
public class SistemaHotel {
    private static final HotelService hotelService = new HotelService();
    private static final Scanner scanner = new Scanner(System.in);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public static void main(String[] args) {
        mostrarBienvenida();
        
        boolean continuar = true;
        while (continuar) {
            try {
                mostrarMenuPrincipal();
                int opcion = leerEntero("Seleccione una opción: ");
                
                continuar = procesarOpcion(opcion);
                
                if (continuar) {
                    System.out.println("\nPresione Enter para continuar...");
                    scanner.nextLine();
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
                scanner.nextLine();
            }
        }
        
        System.out.println("\n¡Gracias por usar el Sistema de Gestión Hotelera!");
        scanner.close();
    }

    private static void mostrarBienvenida() {
        System.out.println("╔═══════════════════════════════════════════════╗");
        System.out.println("║   SISTEMA DE GESTIÓN HOTELERA - JAVA CLI     ║");
        System.out.println("║            Hotel Grand Paradise               ║");
        System.out.println("╚═══════════════════════════════════════════════╝");
        System.out.println();
    }

    private static void mostrarMenuPrincipal() {
        System.out.println("\n┌─────────────────────────────────────┐");
        System.out.println("│          MENÚ PRINCIPAL             │");
        System.out.println("├─────────────────────────────────────┤");
        System.out.println("│ 1.  Registrar Nuevo Cliente         │");
        System.out.println("│ 2.  Buscar Cliente                  │");
        System.out.println("│ 3.  Listar Todos los Clientes       │");
        System.out.println("│ 4.  Ver Habitaciones Disponibles    │");
        System.out.println("│ 5.  Ver Habitaciones por Tipo       │");
        System.out.println("│ 6.  Crear Nueva Reserva             │");
        System.out.println("│ 7.  Consultar Reserva               │");
        System.out.println("│ 8.  Ver Reservas de Cliente         │");
        System.out.println("│ 9.  Realizar Check-in               │");
        System.out.println("│ 10. Realizar Check-out              │");
        System.out.println("│ 11. Cancelar Reserva                │");
        System.out.println("│ 12. Ver Reservas Activas            │");
        System.out.println("│ 13. Calcular Costo de Estancia      │");
        System.out.println("│ 14. Estadísticas del Hotel          │");
        System.out.println("│ 0.  Salir                           │");
        System.out.println("└─────────────────────────────────────┘");
    }

    private static boolean procesarOpcion(int opcion) {
        switch (opcion) {
            case 1: registrarCliente(); break;
            case 2: buscarCliente(); break;
            case 3: listarClientes(); break;
            case 4: verHabitacionesDisponibles(); break;
            case 5: verHabitacionesPorTipo(); break;
            case 6: crearReserva(); break;
            case 7: consultarReserva(); break;
            case 8: verReservasCliente(); break;
            case 9: realizarCheckIn(); break;
            case 10: realizarCheckOut(); break;
            case 11: cancelarReserva(); break;
            case 12: verReservasActivas(); break;
            case 13: calcularCostoEstancia(); break;
            case 14: mostrarEstadisticas(); break;
            case 0: return false;
            default: System.out.println("⚠ Opción inválida. Intente nuevamente.");
        }
        return true;
    }

    private static void registrarCliente() {
        System.out.println("\n═══ REGISTRAR NUEVO CLIENTE ═══");
        try {
            System.out.print("Nombre: ");
            String nombre = scanner.nextLine();
            System.out.print("Apellido: ");
            String apellido = scanner.nextLine();
            System.out.print("Documento (DNI/Pasaporte): ");
            String documento = scanner.nextLine();
            System.out.print("Email: ");
            String email = scanner.nextLine();
            System.out.print("Teléfono: ");
            String telefono = scanner.nextLine();
            System.out.print("Nacionalidad: ");
            String nacionalidad = scanner.nextLine();
            
            String id = hotelService.registrarCliente(nombre, apellido, documento, email, telefono, nacionalidad);
            System.out.println("\n✓ Cliente registrado exitosamente!");
            System.out.println("  ID: " + id);
            System.out.println("  Nombre: " + nombre + " " + apellido);
        } catch (IllegalArgumentException e) {
            System.err.println("✗ Error: " + e.getMessage());
        }
    }

    private static void buscarCliente() {
        System.out.println("\n═══ BUSCAR CLIENTE ═══");
        System.out.print("Ingrese documento: ");
        String documento = scanner.nextLine();
        Optional<Cliente> clienteOpt = hotelService.buscarCliente(documento);
        if (clienteOpt.isPresent()) {
            System.out.println("\n✓ Cliente encontrado:");
            mostrarDetallesCliente(clienteOpt.get());
        } else {
            System.out.println("✗ No se encontró ningún cliente con ese documento.");
        }
    }

    private static void listarClientes() {
        System.out.println("\n═══ LISTA DE CLIENTES ═══");
        List<Cliente> clientes = hotelService.obtenerTodosClientes();
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
            return;
        }
        System.out.println("\nTotal de clientes: " + clientes.size());
        System.out.println("─────────────────────────────────────────────────────────────");
        for (Cliente cliente : clientes) {
            System.out.printf("ID: %s | %s | Doc: %s | Tel: %s%n",
                cliente.getId(), cliente.getNombreCompleto(), cliente.getDocumento(), cliente.getTelefono());
        }
    }

    private static void verHabitacionesDisponibles() {
        System.out.println("\n═══ HABITACIONES DISPONIBLES ═══");
        List<Habitacion> habitaciones = hotelService.consultarHabitacionesDisponibles();
        if (habitaciones.isEmpty()) {
            System.out.println("✗ No hay habitaciones disponibles en este momento.");
            return;
        }
        System.out.println("\nTotal disponibles: " + habitaciones.size());
        System.out.println("─────────────────────────────────────────────────────────────");
        for (Habitacion hab : habitaciones) {
            System.out.printf("\nHabitación %s - %s%n", hab.getNumero(), hab.getTipo().getNombre());
            System.out.printf("  Precio: $%.2f por noche%n", hab.getPrecioPorNoche());
            System.out.printf("  Capacidad: %d persona(s)%n", hab.getCapacidadPersonas());
            System.out.printf("  Descripción: %s%n", hab.getDescripcion());
        }
    }

    private static void verHabitacionesPorTipo() {
        System.out.println("\n═══ HABITACIONES POR TIPO ═══");
        System.out.println("1. Simple");
        System.out.println("2. Doble");
        System.out.println("3. Suite");
        System.out.println("4. Presidencial");
        int opcion = leerEntero("Seleccione tipo: ");
        TipoHabitacion tipo;
        try {
            tipo = TipoHabitacion.desdeOpcionMenu(opcion);
        } catch (IllegalArgumentException e) {
            System.out.println("✗ Opción inválida.");
            return;
        }
        List<Habitacion> habitaciones = hotelService.consultarHabitacionesPorTipo(tipo);
        if (habitaciones.isEmpty()) {
            System.out.println("✗ No hay habitaciones disponibles de este tipo.");
            return;
        }
        System.out.println("\nHabitaciones " + tipo.getNombre() + " disponibles:");
        System.out.println("─────────────────────────────────────────────────────────────");
        for (Habitacion hab : habitaciones) {
            System.out.printf("\nHabitación %s - $%.2f/noche - Cap: %d%n", 
                hab.getNumero(), hab.getPrecioPorNoche(), hab.getCapacidadPersonas());
            System.out.printf("  %s%n", hab.getDescripcion());
        }
    }

    private static void crearReserva() {
        System.out.println("\n═══ CREAR NUEVA RESERVA ═══");
        try {
            System.out.print("Documento del cliente: ");
            String documento = scanner.nextLine();
            Optional<Cliente> clienteOpt = hotelService.buscarCliente(documento);
            if (!clienteOpt.isPresent()) {
                System.out.println("✗ Cliente no encontrado. Debe registrarse primero.");
                return;
            }
            System.out.print("Número de habitación: ");
            String numeroHab = scanner.nextLine();
            System.out.print("Fecha check-in (dd/MM/yyyy): ");
            String fechaInStr = scanner.nextLine();
            LocalDate fechaIn = LocalDate.parse(fechaInStr, DATE_FORMATTER);
            System.out.print("Fecha check-out (dd/MM/yyyy): ");
            String fechaOutStr = scanner.nextLine();
            LocalDate fechaOut = LocalDate.parse(fechaOutStr, DATE_FORMATTER);
            
            String idReserva = hotelService.crearReserva(documento, numeroHab, fechaIn, fechaOut);
            Optional<Reserva> reservaOpt = hotelService.consultarReserva(idReserva);
            if (reservaOpt.isPresent()) {
                Reserva reserva = reservaOpt.get();
                System.out.println("\n✓ Reserva creada exitosamente!");
                System.out.println("  ID Reserva: " + idReserva);
                System.out.println("  Cliente: " + reserva.getCliente().getNombreCompleto());
                System.out.println("  Habitación: " + reserva.getHabitacion().getNumero());
                System.out.println("  Check-in: " + reserva.getFechaCheckIn());
                System.out.println("  Check-out: " + reserva.getFechaCheckOut());
                System.out.println("  Días: " + reserva.getNumeroDias());
                System.out.printf("  Costo Total: $%.2f%n", reserva.getCostoTotal());
            }
        } catch (DateTimeParseException e) {
            System.err.println("✗ Error: Formato de fecha inválido. Use dd/MM/yyyy");
        } catch (IllegalArgumentException e) {
            System.err.println("✗ Error: " + e.getMessage());
        }
    }

    private static void consultarReserva() {
        System.out.println("\n═══ CONSULTAR RESERVA ═══");
        System.out.print("ID de la reserva: ");
        String idReserva = scanner.nextLine();
        Optional<Reserva> reservaOpt = hotelService.consultarReserva(idReserva);
        if (reservaOpt.isPresent()) {
            System.out.println("\n✓ Reserva encontrada:");
            mostrarDetallesReserva(reservaOpt.get());
        } else {
            System.out.println("✗ No se encontró la reserva.");
        }
    }

    private static void verReservasCliente() {
        System.out.println("\n═══ RESERVAS DE CLIENTE ═══");
        System.out.print("Documento del cliente: ");
        String documento = scanner.nextLine();
        List<Reserva> reservas = hotelService.consultarReservasCliente(documento);
        if (reservas.isEmpty()) {
            System.out.println("✗ El cliente no tiene reservas registradas.");
            return;
        }
        System.out.println("\nTotal de reservas: " + reservas.size());
        System.out.println("─────────────────────────────────────────────────────────────");
        for (Reserva reserva : reservas) {
            mostrarDetallesReserva(reserva);
            System.out.println("─────────────────────────────────────────────────────────────");
        }
    }

    private static void realizarCheckIn() {
        System.out.println("\n═══ REALIZAR CHECK-IN ═══");
        System.out.print("ID de la reserva: ");
        String idReserva = scanner.nextLine();
        try {
            hotelService.realizarCheckIn(idReserva);
            System.out.println("✓ Check-in realizado exitosamente!");
            System.out.println("  Estado: EN CURSO");
        } catch (IllegalArgumentException e) {
            System.err.println("✗ Error: " + e.getMessage());
        }
    }

    private static void realizarCheckOut() {
        System.out.println("\n═══ REALIZAR CHECK-OUT ═══");
        System.out.print("ID de la reserva: ");
        String idReserva = scanner.nextLine();
        try {
            double costoTotal = hotelService.realizarCheckOut(idReserva);
            System.out.println("\n✓ Check-out realizado exitosamente!");
            System.out.printf("  Costo Total a Pagar: $%.2f%n", costoTotal);
            System.out.println("  ¡Gracias por hospedarse con nosotros!");
        } catch (IllegalArgumentException e) {
            System.err.println("✗ Error: " + e.getMessage());
        }
    }

    private static void cancelarReserva() {
        System.out.println("\n═══ CANCELAR RESERVA ═══");
        System.out.print("ID de la reserva: ");
        String idReserva = scanner.nextLine();
        try {
            System.out.print("¿Está seguro? (S/N): ");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("S")) {
                hotelService.cancelarReserva(idReserva);
                System.out.println("✓ Reserva cancelada exitosamente.");
            } else {
                System.out.println("✗ Cancelación abortada.");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("✗ Error: " + e.getMessage());
        }
    }

    private static void verReservasActivas() {
        System.out.println("\n═══ RESERVAS ACTIVAS ═══");
        List<Reserva> reservas = hotelService.consultarReservasActivas();
        if (reservas.isEmpty()) {
            System.out.println("No hay reservas activas en este momento.");
            return;
        }
        System.out.println("\nTotal de reservas activas: " + reservas.size());
        System.out.println("─────────────────────────────────────────────────────────────");
        for (Reserva reserva : reservas) {
            mostrarDetallesReserva(reserva);
            System.out.println("─────────────────────────────────────────────────────────────");
        }
    }

    private static void calcularCostoEstancia() {
        System.out.println("\n═══ CALCULAR COSTO DE ESTANCIA ═══");
        System.out.println("Tipo de habitación:");
        System.out.println("1. Simple");
        System.out.println("2. Doble");
        System.out.println("3. Suite");
        System.out.println("4. Presidencial");
        int opcion = leerEntero("Seleccione tipo: ");
        TipoHabitacion tipo;
        try {
            tipo = TipoHabitacion.desdeOpcionMenu(opcion);
        } catch (IllegalArgumentException e) {
            System.out.println("✗ Opción inválida.");
            return;
        }
        int dias = leerEntero("Número de días: ");
        double costo = hotelService.calcularCostoReserva(tipo, dias);
        System.out.println("\n═══ ESTIMACIÓN DE COSTO ═══");
        System.out.println("Tipo: " + tipo.getNombre());
        System.out.println("Días: " + dias);
        System.out.printf("Costo Total Estimado: $%.2f%n", costo);
    }

    private static void mostrarEstadisticas() {
        System.out.println("\n═══ ESTADÍSTICAS DEL HOTEL ═══");
        System.out.println("Total de clientes registrados: " + hotelService.obtenerEstadisticaClientes());
        System.out.println("Total de reservas: " + hotelService.obtenerEstadisticaReservas());
        System.out.println("Habitaciones disponibles: " + hotelService.obtenerEstadisticaHabitacionesDisponibles());
        System.out.println("Reservas activas: " + hotelService.consultarReservasActivas().size());
    }

    private static void mostrarDetallesCliente(Cliente cliente) {
        System.out.println("  ID: " + cliente.getId());
        System.out.println("  Nombre: " + cliente.getNombreCompleto());
        System.out.println("  Documento: " + cliente.getDocumento());
        System.out.println("  Email: " + cliente.getEmail());
        System.out.println("  Teléfono: " + cliente.getTelefono());
        System.out.println("  Nacionalidad: " + cliente.getNacionalidad());
    }

    private static void mostrarDetallesReserva(Reserva reserva) {
        System.out.println("\n  ID Reserva: " + reserva.getId());
        System.out.println("  Cliente: " + reserva.getCliente().getNombreCompleto());
        System.out.println("  Habitación: " + reserva.getHabitacion().getNumero() + 
                          " (" + reserva.getHabitacion().getTipo().getNombre() + ")");
        System.out.println("  Check-in: " + reserva.getFechaCheckIn());
        System.out.println("  Check-out: " + reserva.getFechaCheckOut());
        System.out.println("  Días: " + reserva.getNumeroDias());
        System.out.printf("  Costo Total: $%.2f%n", reserva.getCostoTotal());
        System.out.println("  Estado: " + reserva.getEstado().getDescripcion());
    }

    private static int leerEntero(String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                return scanner.nextInt();
            } catch (Exception e) {
                System.out.println("✗ Error: Ingrese un número válido.");
                scanner.nextLine();
            }
        }
    }
}
