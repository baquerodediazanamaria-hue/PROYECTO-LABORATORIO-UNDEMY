package data;

import model.Cliente;
import model.Habitacion;
import model.Habitacion.TipoHabitacion;
import model.Reserva;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Simula una base de datos en memoria para el sistema hotelero.
 */
public class BaseDatosHotel {
    private static List<Cliente> clientes = new ArrayList<>();
    private static List<Habitacion> habitaciones = new ArrayList<>();
    private static List<Reserva> reservas = new ArrayList<>();
    private static int contadorClientes = 1;
    private static int contadorReservas = 1;

    static {
        inicializarDatos();
    }

    private static void inicializarDatos() {
        habitaciones.add(new Habitacion("101", TipoHabitacion.SIMPLE, 50.0, 1, 
            "Habitación simple con cama individual y baño privado"));
        habitaciones.add(new Habitacion("102", TipoHabitacion.SIMPLE, 50.0, 1, 
            "Habitación simple con vista al jardín"));
        habitaciones.add(new Habitacion("201", TipoHabitacion.DOBLE, 80.0, 2, 
            "Habitación doble con cama matrimonial"));
        habitaciones.add(new Habitacion("202", TipoHabitacion.DOBLE, 85.0, 2, 
            "Habitación doble con dos camas y balcón"));
        habitaciones.add(new Habitacion("301", TipoHabitacion.SUITE, 150.0, 4, 
            "Suite con sala de estar y jacuzzi"));
        habitaciones.add(new Habitacion("302", TipoHabitacion.SUITE, 160.0, 4, 
            "Suite Premium con vista panorámica"));
        habitaciones.add(new Habitacion("401", TipoHabitacion.PRESIDENCIAL, 300.0, 6, 
            "Suite Presidencial con comedor privado y terraza"));
    }

    public static String generarIdCliente() {
        return "CLI" + String.format("%04d", contadorClientes++);
    }

    public static String generarIdReserva() {
        return "RES" + String.format("%04d", contadorReservas++);
    }

    public static void agregarCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    public static void agregarReserva(Reserva reserva) {
        reservas.add(reserva);
    }

    public static Optional<Cliente> buscarClientePorDocumento(String documento) {
        return clientes.stream()
                .filter(c -> c.getDocumento().equalsIgnoreCase(documento))
                .findFirst();
    }

    public static Optional<Habitacion> buscarHabitacionPorNumero(String numero) {
        return habitaciones.stream()
                .filter(h -> h.getNumero().equals(numero))
                .findFirst();
    }

    public static Optional<Reserva> buscarReservaPorId(String id) {
        return reservas.stream()
                .filter(r -> r.getId().equals(id))
                .findFirst();
    }

    public static List<Habitacion> obtenerHabitacionesDisponibles() {
        return habitaciones.stream()
                .filter(Habitacion::isDisponible)
                .collect(Collectors.toList());
    }

    public static List<Habitacion> obtenerHabitacionesPorTipo(TipoHabitacion tipo) {
        return habitaciones.stream()
                .filter(h -> h.getTipo() == tipo && h.isDisponible())
                .collect(Collectors.toList());
    }

    public static List<Reserva> obtenerReservasPorCliente(String documentoCliente) {
        return reservas.stream()
                .filter(r -> r.getCliente().getDocumento().equalsIgnoreCase(documentoCliente))
                .collect(Collectors.toList());
    }

    public static List<Reserva> obtenerReservasActivas() {
        return reservas.stream()
                .filter(r -> r.getEstado() == Reserva.EstadoReserva.CONFIRMADA || 
                            r.getEstado() == Reserva.EstadoReserva.EN_CURSO)
                .collect(Collectors.toList());
    }

    public static List<Cliente> obtenerTodosClientes() {
        return new ArrayList<>(clientes);
    }

    public static List<Habitacion> obtenerTodasHabitaciones() {
        return new ArrayList<>(habitaciones);
    }

    public static List<Reserva> obtenerTodasReservas() {
        return new ArrayList<>(reservas);
    }

    public static void eliminarReserva(Reserva reserva) {
        reservas.remove(reserva);
    }

    public static int getCantidadClientes() {
        return clientes.size();
    }

    public static int getCantidadReservas() {
        return reservas.size();
    }

    public static int getCantidadHabitaciones() {
        return habitaciones.size();
    }
}
